// Backend code for login page
const users = [
    { loginId: 'user1', password: 'password1' },
    { loginId: 'user2', password: 'password2' },
    { loginId: 'user3', password: 'password3' }
  ];
  
  function createAccount(loginId, password) {
    users.push({ loginId, password });
  }
  
  // Create a new account
  createAccount('newUser', 'newPassword');
  
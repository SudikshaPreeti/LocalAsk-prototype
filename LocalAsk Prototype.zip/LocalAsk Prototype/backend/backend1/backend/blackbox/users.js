// let people = [
//     {
//       name: "Hannah Rickard",
//       number: "06-51-99-56-83",
//       id: 1
//     },
//     {
//       name: "Hyun Namkoong",
//       number: "10987654",
//       id: 2
//     },
//     {
//       name: "Courtney Martinez",
//       number: "3691215",
//       id: 3
//     }
// ]
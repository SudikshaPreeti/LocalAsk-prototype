// const express = require('express');
// const app = express();
// const PORT = 3000;

// // Middleware
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// // Route Definitions
// app.get('/', (request, response) => {
//   response.send('<h1>Welcome to our LinkedIn clone!</h1>');
// });

// app.get('/api/people', (request, response) => {
//   response.json(people);
// });

// app.post('/register', (req, res) => {
//   // Your registration logic will go here
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

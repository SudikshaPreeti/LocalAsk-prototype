const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = process.env.PORT || 3000;

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/history_db', { useNewUrlParser: true, useUnifiedTopology: true });

// Mongoose Model for History
const History = mongoose.model('History', new mongoose.Schema({
    action: String,
    timestamp: { type: Date, default: Date.now }
}));

// Middleware to log requests
app.use((req, res, next) => {
    const { method, url } = req;
    const action = `${method} ${url}`;

    // Save the action to the database
    const historyEntry = new History({ action });
    historyEntry.save();

    next();
});

// Route to retrieve history
app.get('/history', async (req, res) => {
    try {
        const history = await History.find().sort({ timestamp: -1 });
        res.json(history);
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching history');
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

import React, { useState, useEffect } from 'react';

function HistorySaver() {
  const [history, setHistory] = useState([]);

  // Function to fetch history from backend
  const fetchHistory = async () => {
    try {
      const response = await fetch('/history');
      const data = await response.json();
      setHistory(data);
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  // Fetch history when component mounts
  useEffect(() => {
    fetchHistory();
  }, []);

  return (
    <div>
      <h2>History</h2>
      <ul>
        {history.map((entry, index) => (
          <li key={index}>{entry.action}</li>
        ))}
      </ul>
    </div>
  );
}

export default HistorySaver;
